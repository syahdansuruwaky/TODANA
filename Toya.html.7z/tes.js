function addToCart(productName) {
  const nomorWA = "6282154677303";
  const pesan = `Halo! Saya ingin membeli ${productName}. Apakah masih tersedia?`;
  const url = `https://wa.me/6282199804156${nomorWA}?text=${encodeURIComponent(pesan)}`;
  window.open(url, '_blank');
}